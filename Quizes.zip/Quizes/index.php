<html>
<head>
	<title> Quizer</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
		<div class="container">
			<p>PHP Quizer</p>
		</div>
	</header>

	<main>
    <div class = "menu">
<a href="main.php" class="button">Take Quiz</a>
<a href="add.php" class="button">Add questions</a>
</div>
	</main>
</body>
</html>
